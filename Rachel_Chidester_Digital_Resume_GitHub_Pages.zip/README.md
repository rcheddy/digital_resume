# Rachel Chidester — Digital Resume

A **fast, free, recruiter-friendly, mobile-responsive HTML resume** designed to be hosted using GitHub Pages. No hosting fees, no frameworks, no JavaScript, no cookies, and no tracking.

## Contents

- `index.html` — public profile and full experience, with structured `ProfilePage` / `Person` JSON-LD.
- `styles.css` — responsive design, accessibility and print styles.
- `Rachel_Chidester_Resume.pdf` — phone-number-free, selectable-text resume for visitors.
- `resume.json` — machine-readable JSON Resume-format career information.
- `resume.txt` — basic plain-text resume.
- `robots.txt` — basic crawl permission for public site (note: for GitHub project Pages, robots.txt at the project path may not be used as the host-level robots policy).
- `llms.txt` — optional plain-text professional summary for tools that choose to read it; no discovery guarantees.
- `favicon.svg` and `.nojekyll` — small site assets.
- `sitemap.xml.template` — prepare a real sitemap when you know the final public URL.

## Publish for FREE using GitHub Pages (no coding required)

1. Use **Rachel's own personal GitHub account**, not ShelterPawtners' project account. Create a free account if needed: https://github.com/signup
2. Go to https://github.com/new and create a **Public** repository named `rachel-digital-resume` with a README or start empty. On GitHub Free, Pages is free for public repositories.
3. Unzip this package. In the new repository, choose **Add file → Upload files**, then drag *the extracted files* (not the ZIP) into the repository and commit them to `main`. Upload `index.html` and `styles.css` at the top level. Files beginning with `.` might be hidden by some file pickers; `.nojekyll` is optional for this plain site.
4. Open repository **Settings → Pages → Build and deployment → Source: Deploy from a branch**. Select `main` and `/(root)`; click Save.
5. GitHub will display the published URL, usually `https://YOUR_USERNAME.github.io/rachel-digital-resume/`. Verify it works on desktop and phone. Publishing can take some time; check Settings → Pages for the actual deployment status.
6. Share the actual URL in the **Featured** section and website field of your LinkedIn profile, in your email signature, and on applications where a portfolio URL is accepted.

## Finish the SEO setup after publication

1. Open `index.html` and add a canonical URL to `<head>` using the **real** Pages URL, e.g. `<link rel="canonical" href="https://YOUR_USERNAME.github.io/rachel-digital-resume/">`. Never publish a fake placeholder as the canonical URL.
2. Copy `sitemap.xml.template` to `sitemap.xml`; replace the example address with your real URL. Commit it. Optionally add `Sitemap: https://YOUR_USERNAME.github.io/rachel-digital-resume/sitemap.xml` to `robots.txt`; note that project-level robots.txt does not control the domain root.
3. Verify ownership in Google Search Console (https://search.google.com/search-console/about) using the published URL and submit `sitemap.xml` where supported.
4. Ask a trusted colleague to inspect the page, verify all dates, achievements, links, and email address before sharing widely.
5. Update the site when your role, experience, certification, or career focus changes.

## Practical ATS guidance

**ATS platforms usually parse the resume file uploaded with each job application; they do not automatically import personal websites.** For applications, upload a role-tailored PDF or DOCX separately. This site makes it easier for recruiters and search engines to discover and read your experience, while `resume.txt`, `resume.json`, selectable PDF text, and semantic HTML improve machine-readability. None guarantees search ranking or an ATS score.

## Privacy & content accuracy

- This public version shows email and LinkedIn but **does not display a personal phone number**. Your privately submitted job application may include your phone.
- The site reflects the resume's documented roles and metrics. It does **not** claim direct pharmaceutical clinical-trial management, drug discovery, or active CNIM / athletic-trainer licensure.
- The Girls in Science Fellowship statement links to a publicly accessible post on Rachel's existing LinkedIn URL; the entire LinkedIn profile could not be independently read due to access restrictions.
- Personal website files in a public GitHub repository are visible to anyone. Don't put unpublished documents, addresses, private references, passwords, or anything else sensitive into this repository.

## Editing

Open `index.html` or `styles.css` using a code editor or GitHub's online file editor. Change visible text directly and update duplicate data in `resume.json`, `resume.txt`, `llms.txt`, and downloadable PDF for consistency.

Built 23 November 2026.
